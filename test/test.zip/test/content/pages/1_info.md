﻿+++
title = "お知らせ"
date = "2017-03-01"
weight = "1"
comment = "更新中！"

+++

#### 礼拝
毎週日曜日 10:30-12:00
礼拝は日本語です。韓国語での同時通訳も行っています。
#### 祈祷会
毎週木曜日19:00-21:00
テーマに基づいた聖書の学びとお祈りの時間を持ちます。

#### 最新の情報は↓



<a href="https://twitter.com/hitachi_hikari" class="twitter-follow-button" data-show-count="false"></a>
<script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>

<a class="twitter-timeline" href="https://twitter.com/hitachi_hikari"></a>
<script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>



