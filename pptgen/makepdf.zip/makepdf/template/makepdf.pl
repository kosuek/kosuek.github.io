#! usr/local/bin/perl -w
use Cwd;

my ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) = localtime;
$year = sprintf("%d",$year+1900);
$mon = sprintf("%02d",$mon);
$mday = sprintf("%02d",$mday);

$now=$year.$mon.$mday;

$template = "<./template/template.html";
if(open (DAT, $template )){@reg = <DAT>;close DAT;}
else{print("$template not found\n",);}
chomp(@reg);

$template = "<./md.md";
if(open (DAT, $template )){@md = <DAT>;close DAT;}
else{print("$template not found\n",);}
chomp(@md);

open $outfile, "> ./$now.html";
foreach $reg(@reg){
		if($reg eq '					<script type="text/template">'){
			printf $outfile ("$reg\n");
			foreach $md(@md){printf $outfile ("$md\n");}
		}else {printf $outfile ("$reg\n");}}

$wd = Cwd::getcwd();
$command = "start chrome file:///".$wd."/".$now.".html";

system($command);

