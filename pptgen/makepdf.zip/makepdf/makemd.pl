﻿#! usr/local/bin/perl -w
use Cwd;

@reg = qw(aa aa aa aa aa aa);

$template = "<./template/template.md";
if(open (DAT, $template )){@reg = <DAT>;close DAT;}
else{print("$template not found\n",);}
chomp(@reg);

open $outfile, "> ./md.md";

foreach $reg(@reg){
		if(substr($reg,0,1) eq 'b'){
			#週報から聖書箇所をとってくる
			#1節ずつに分解
			@bible_qw = qw(1 2 3 4 5);
			#節指定でDBから文章とってくる
			foreach $bible_qw(@bible_qw){
				$bible = "## ".$bible_qw;
				printf $outfile ("$bible\n");
				$bible = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.";
				printf $outfile ("$bible\n");
				printf $outfile ("\n\n\---\n\n");
			}
			
		}
		elsif(substr($reg,0,1) eq 's'){
			#週報から聖歌箇所をとってくる
			#1節ずつ格納
			#サイズ調整
			@seika_qw = qw(1 2 3 4);
			foreach $seika_qw(@seika_qw){
				$seika = "## ".$seika_qw;
				printf $outfile ("$seika\n");
				$seika = "あいうえおあいうえおあいうえおあいうえお  \nあいうえおあいうえおあいうえおあいうえお  \nあいうえおあいうえおあいうえおあいうえお  \nあいうえおあいうえおあいうえおあいうえお  \nあいうえおあいうえおあいうえおあいうえお";
				printf $outfile ("$seika\n");
				printf $outfile ("\n\n\---\n\n");
			}
		}
		else {
			printf $outfile ("$reg\n");
		}
}

$wd = Cwd::getcwd();
$command = "perl ./template/makepdf.pl";

system($command);

